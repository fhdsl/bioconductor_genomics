install.packages("BiocManager")
BiocManager::install(c("SummarizedExperiment", "DESeq2",
                       "clusterProfiler", "tidySummarizedExperiment",
                       "org.Mm.eg.db", "ComplexHeatmap"))